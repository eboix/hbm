% 3-vertex path.
n = 3;
m = 2;
edge_list = [[1 2 4]; [2 3 5]];
p2inf = get_symbolic_mut_inf(n,m,edge_list);

% Example graph from today.
n = 3;
m = 3;
edge_list = [[1 2 4]; [2 3 5]; [2 3 6]];
sampleinf = get_symbolic_mut_inf(n,m,edge_list);

% Try to minimize this expression, to see if 2*p2inf >= sampleinf always!
expr = 2*p2inf - sampleinf;
ezsurfc(expr,[0 1])
hold on
ezsurfc(sampleinf,[0 1])
view(127,38)

