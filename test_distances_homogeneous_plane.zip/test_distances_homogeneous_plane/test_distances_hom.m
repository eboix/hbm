n = 400000; % Number of points.
L = sqrt(n); % Unit square has density 1.

c = 4; % threshold distance
t = 1; % connect points under threshold distance with this probability

% Generate positions, and set pos(1,:) to be a point in the center.
pos = rand(n,2)*L;
pos(1,:) = [L/2 L/2];

% Find adjacency list without intersecting with G(n,t) yet.
GrphKDT = KDTreeSearcher(pos);
adj_list = rangesearch(GrphKDT,pos,c); % Get adj list.
templ = cellfun(@(x) length(x), adj_list);
adj_list = [rldecode(templ, 1:n); adj_list{:}]';
adj_list = adj_list(adj_list(:,1) < adj_list(:,2),:); % List each edge once.

% Subsample edges (i.e., intersect with G(n,t)).
adj_list = adj_list(rand(length(adj_list), 1) < t,:);

% Create graph
num_edges = length(adj_list(:,1));
A = sparse(adj_list(:,1), adj_list(:,2),1,n,n,num_edges); 
A = A + A';
g = graph(A);
disp('Graph generated.')

% Output size of giant component.
[sbincount,comp] = get_comp_sizes(g);
giant_idx = find(comp == 1); % Giant component indices.
disp(sbincount(1));

% s = giant_idx(1);
s = 1;

graph_d = distances(g, s); % Graph distances.
straight_d = zeros(samp, n); % Straight-line distances.
for i = 1:length(s)
    s_val = s(i);
    straight_d(i,:) = sqrt((pos(s_val,1) - pos(:,1)).^2 + (pos(s_val,2) - pos(:,2)).^2);
end

sds = straight_d(:); % flatten straight_d
rats = graph_d ./ straight_d * c; % Calculate graph_d / straight_d ratios
rats = rats(:);

% Drawing option 1: Draw density plot of straight-line distance (x) vs. ratios (y).
min_y = 1;
max_y = 2;
cropped_density([sds rats], [10000 100], [0 max(sds) min_y max_y]);
h = gca;
h.YDir = 'normal';

% Drawing option 2: Draw histograms for points at least distance i away.
% for i = 1:300
%     histogram(rats(sds > i))
%     pause(0.05)
% end